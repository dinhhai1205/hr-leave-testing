"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ROUNDING_TIME_SHEET_THRESHOLD_CONSTANT = exports.ROUNDING_TIME_SHEET_BASE_CONSTANT = void 0;
exports.ROUNDING_TIME_SHEET_BASE_CONSTANT = 0.5;
exports.ROUNDING_TIME_SHEET_THRESHOLD_CONSTANT = 1;
//# sourceMappingURL=time-sheet-base.constanst.js.map