import type { ColumnOptions } from 'typeorm';
export declare const BIGINT_COLUMN_TYPE: ColumnOptions;
