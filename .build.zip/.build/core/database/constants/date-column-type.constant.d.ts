import type { ColumnOptions } from 'typeorm';
export declare const DATE_COLUMN_TYPE: ColumnOptions;
