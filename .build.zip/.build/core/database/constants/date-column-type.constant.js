"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DATE_COLUMN_TYPE = void 0;
const utils_1 = require("../utils");
exports.DATE_COLUMN_TYPE = {
    type: 'date',
    transformer: (0, utils_1.dateTransformer)(),
};
//# sourceMappingURL=date-column-type.constant.js.map