import type { ColumnOptions } from 'typeorm';
export declare const NUMERIC_COLUMN_TYPE: ColumnOptions;
