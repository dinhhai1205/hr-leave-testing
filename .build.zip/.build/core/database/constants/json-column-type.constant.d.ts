import type { ColumnOptions } from 'typeorm';
export declare const JSON_COLUMN_TYPE: ColumnOptions;
