import type { ColumnOptions } from 'typeorm';
export declare const DATETIME_WITHOUT_TZ_COLUMN_TYPE: ColumnOptions;
