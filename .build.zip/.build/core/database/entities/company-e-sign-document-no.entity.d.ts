export declare class CompanyESignDocumentNoEntity {
    id: number;
    isdeleted: boolean;
    companyid: number;
    lastno: number;
}
