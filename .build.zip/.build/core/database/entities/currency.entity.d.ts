import { AbstractEntity } from './abstract.entity';
export declare class CurrencyEntity extends AbstractEntity {
    id: number;
    code: string;
    name: string;
}
