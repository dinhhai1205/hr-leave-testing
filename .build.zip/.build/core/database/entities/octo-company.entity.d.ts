import { AbstractEntity } from './abstract.entity';
export declare class OctoCompanyEntity extends AbstractEntity {
    id: number;
    active: boolean;
    code: string;
    name: string;
}
