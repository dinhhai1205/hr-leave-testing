"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=permission-actions.interface.js.map