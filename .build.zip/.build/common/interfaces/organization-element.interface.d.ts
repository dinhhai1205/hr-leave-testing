export interface IOrganizationElement {
    OrgEleId: number;
    OrgEleName: string;
    OrgPath: string;
}
