export interface IObjectLiteral {
    [key: string]: any;
}
