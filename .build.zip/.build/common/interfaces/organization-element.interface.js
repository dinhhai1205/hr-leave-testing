"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=organization-element.interface.js.map