export declare enum EPayrollHeaderStatus {
    DRAFT = 0,
    FINALIZED = 2
}
