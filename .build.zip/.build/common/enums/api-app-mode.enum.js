"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EApiAppMode = void 0;
var EApiAppMode;
(function (EApiAppMode) {
    EApiAppMode["ADMIN"] = "admin";
    EApiAppMode["ESS"] = "ess";
})(EApiAppMode || (exports.EApiAppMode = EApiAppMode = {}));
//# sourceMappingURL=api-app-mode.enum.js.map