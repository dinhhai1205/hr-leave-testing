export declare enum EHistorySign {
    ADD = 1,
    MINUS = -1
}
