"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EMainModuleNumber = exports.EMainModule = void 0;
var EMainModule;
(function (EMainModule) {
    EMainModule["EMPLOYEE"] = "EMPLOYEE";
    EMainModule["LEAVE"] = "LEAVE";
    EMainModule["PAYROLL"] = "PAYROLL";
    EMainModule["APPROVAL"] = "APPROVAL";
})(EMainModule || (exports.EMainModule = EMainModule = {}));
var EMainModuleNumber;
(function (EMainModuleNumber) {
    EMainModuleNumber[EMainModuleNumber["EMPLOYEE"] = 1] = "EMPLOYEE";
    EMainModuleNumber[EMainModuleNumber["LEAVE"] = 2] = "LEAVE";
    EMainModuleNumber[EMainModuleNumber["PAYROLL"] = 5] = "PAYROLL";
})(EMainModuleNumber || (exports.EMainModuleNumber = EMainModuleNumber = {}));
//# sourceMappingURL=module.enum.js.map