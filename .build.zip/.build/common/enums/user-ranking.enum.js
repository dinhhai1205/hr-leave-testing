"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EUserRanking = void 0;
var EUserRanking;
(function (EUserRanking) {
    EUserRanking["SILVER"] = "SILVER";
    EUserRanking["GOLD"] = "GOLD";
})(EUserRanking || (exports.EUserRanking = EUserRanking = {}));
//# sourceMappingURL=user-ranking.enum.js.map