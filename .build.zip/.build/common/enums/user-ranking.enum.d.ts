export declare enum EUserRanking {
    SILVER = "SILVER",
    GOLD = "GOLD"
}
