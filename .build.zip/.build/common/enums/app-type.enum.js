"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EAppType = void 0;
var EAppType;
(function (EAppType) {
    EAppType["HRFORTE"] = "hrforte";
    EAppType["MAP_HRFORTE"] = "map-hrforte";
})(EAppType || (exports.EAppType = EAppType = {}));
//# sourceMappingURL=app-type.enum.js.map