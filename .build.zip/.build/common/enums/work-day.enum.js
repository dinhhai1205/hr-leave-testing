"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EWorkDay = void 0;
var EWorkDay;
(function (EWorkDay) {
    EWorkDay[EWorkDay["WORKING_DAY"] = 1] = "WORKING_DAY";
    EWorkDay[EWorkDay["WORKING_HALF_DAY"] = 0.5] = "WORKING_HALF_DAY";
    EWorkDay[EWorkDay["DAY_OFF"] = 0] = "DAY_OFF";
})(EWorkDay || (exports.EWorkDay = EWorkDay = {}));
//# sourceMappingURL=work-day.enum.js.map