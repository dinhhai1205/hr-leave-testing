export declare enum ELeaveApprovalActions {
    submit = "AWAIT_APPROVAL",
    approve = "APPROVED",
    decline = "DECLINE",
    recall = "DRAFT",
    cancel = "CANCELLED"
}
