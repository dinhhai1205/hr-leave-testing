"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ERole = void 0;
var ERole;
(function (ERole) {
    ERole["ADMIN"] = "admin";
    ERole["ESS"] = "ess";
})(ERole || (exports.ERole = ERole = {}));
//# sourceMappingURL=role.enum.js.map