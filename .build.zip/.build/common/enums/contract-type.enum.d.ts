export declare enum EContractType {
    DEFINITE = "FT",
    INDEFINITE = "PM",
    PROJECT_SEASONAL = "PT",
    PROBATION = "PB"
}
