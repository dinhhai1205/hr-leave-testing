export declare enum ELeaveDayOff {
    FULL_DAY_OFF = 0,
    HALF_DAY_OFF = 0.5
}
