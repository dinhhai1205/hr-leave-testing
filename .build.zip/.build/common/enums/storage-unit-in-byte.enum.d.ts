export declare enum StorageUnitInByte {
    OneKb = 1024,
    OneMb = 1048576,
    OneGb = 1073741824
}
