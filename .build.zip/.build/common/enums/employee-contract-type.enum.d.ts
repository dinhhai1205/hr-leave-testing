export declare enum EEmployeeContractType {
    DEFINITE_CONTRACT = "FT",
    INDEFINITE_CONTRACT = "PM",
    PROJECT_SEASONAL_CONTRACT = "PT",
    PROBATION_CONTRACT = "PB"
}
