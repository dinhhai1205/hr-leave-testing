export declare enum EAppType {
    HRFORTE = "hrforte",
    MAP_HRFORTE = "map-hrforte"
}
