"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ESkipFlag = void 0;
var ESkipFlag;
(function (ESkipFlag) {
    ESkipFlag["AUTHORIZATION"] = "AUTHORIZATION";
    ESkipFlag["COMPANY_ID"] = "COMPANY_ID";
    ESkipFlag["OCTO_AUTHORIZATION"] = "OCTO_AUTHORIZATION";
    ESkipFlag["API_LOG"] = "API_LOG";
})(ESkipFlag || (exports.ESkipFlag = ESkipFlag = {}));
//# sourceMappingURL=skip-flag.enum.js.map