export declare enum EUserAgreementActions {
    AGREE = "AGREE",
    DECLINE = "DECLINE"
}
