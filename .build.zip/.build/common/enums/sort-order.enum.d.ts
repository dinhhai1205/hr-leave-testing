export declare enum EOrder {
    ASC = "ASC",
    DESC = "DESC"
}
export declare enum EOrderNumber {
    ASC = 1,
    DESC = -1
}
