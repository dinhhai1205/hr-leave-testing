export declare enum EWorkForceCategories {
    'A-100' = "Income Per Contract",
    'A-110' = "Income Per Statutory",
    'B-200' = "Taxable BIK",
    'B-210' = "Non-Taxable BIK"
}
