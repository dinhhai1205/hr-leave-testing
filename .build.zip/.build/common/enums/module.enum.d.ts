export declare enum EMainModule {
    EMPLOYEE = "EMPLOYEE",
    LEAVE = "LEAVE",
    PAYROLL = "PAYROLL",
    APPROVAL = "APPROVAL"
}
export declare enum EMainModuleNumber {
    EMPLOYEE = 1,
    LEAVE = 2,
    PAYROLL = 5
}
