export declare enum EMainModule {
    EMPLOYEE = "EMPLOYEE",
    LEAVE = "LEAVE",
    PAYROLL = "PAYROLL",
    APPROVAL = "APPROVAL",
    WORK_SCHEDULE = "WORK_SCHEDULE"
}
export declare enum EMainModuleNumber {
    EMPLOYEE = 1,
    LEAVE = 2,
    PAYROLL = 5,
    WORK_SCHEDULE = 20
}
