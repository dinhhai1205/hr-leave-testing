export declare enum EExcelFileType {
    XLSX = "xlsx",
    CSV = "csv"
}
