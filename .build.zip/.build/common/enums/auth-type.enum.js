"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EAuthType = void 0;
var EAuthType;
(function (EAuthType) {
    EAuthType["HRFORTE"] = "hrforte";
    EAuthType["OCTOPRO"] = "octopro";
})(EAuthType || (exports.EAuthType = EAuthType = {}));
//# sourceMappingURL=auth-type.enum.js.map