"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EExcelFileType = void 0;
var EExcelFileType;
(function (EExcelFileType) {
    EExcelFileType["XLSX"] = "xlsx";
    EExcelFileType["CSV"] = "csv";
})(EExcelFileType || (exports.EExcelFileType = EExcelFileType = {}));
//# sourceMappingURL=excel-file-type.enum.js.map