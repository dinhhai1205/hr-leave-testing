export declare enum EApiModuleMode {
    Leave = "leave",
    Payroll = "payroll",
    Approval = "approval",
    ESign = "esign",
    StatutoryReport = "statRpt"
}
