export declare enum EStorageUnits {
    KB = 1024,
    MB = 1048576,
    GB = 1073741824
}
