"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EBoolean = void 0;
var EBoolean;
(function (EBoolean) {
    EBoolean["TRUE"] = "true";
    EBoolean["FALSE"] = "false";
})(EBoolean || (exports.EBoolean = EBoolean = {}));
//# sourceMappingURL=boolean.enum.js.map