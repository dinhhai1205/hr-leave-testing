export declare enum EApprovalActions {
    SUBMIT = "AWAIT_APPROVAL",
    APPROVE = "APPROVED",
    DECLINE = "DECLINE",
    RECALL = "DRAFT",
    CANCEL = "CANCELLED"
}
