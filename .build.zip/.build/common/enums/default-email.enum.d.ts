export declare enum EDefaultEmail {
    CRON_JOB = "cronjob@hrforte.com",
    BOT = "bot@hrforte.com",
    HRF_LEAVE = "hrfleave@hrforte.com",
    SYSTEM_GENERATED = "system_generated@hrforte.com",
    SLACK_BOT = "slack_bot@hrforte.com"
}
