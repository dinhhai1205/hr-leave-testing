"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EHistorySign = void 0;
var EHistorySign;
(function (EHistorySign) {
    EHistorySign[EHistorySign["ADD"] = 1] = "ADD";
    EHistorySign[EHistorySign["MINUS"] = -1] = "MINUS";
})(EHistorySign || (exports.EHistorySign = EHistorySign = {}));
//# sourceMappingURL=history-sign.enum.js.map