export declare enum ETimeInMillisecond {
    OneSecond = 1000,
    OneMinute = 60000,
    OneHour = 3600000
}
