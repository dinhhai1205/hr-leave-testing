export declare enum EBoolean {
    TRUE = "true",
    FALSE = "false"
}
