export declare enum ENodeEnv {
    PRODUCTION = "production",
    STAGING = "staging",
    LOCAL = "local",
    TEST = "test"
}
