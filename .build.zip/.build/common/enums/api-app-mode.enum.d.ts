export declare enum EApiAppMode {
    ADMIN = "admin",
    ESS = "ess"
}
