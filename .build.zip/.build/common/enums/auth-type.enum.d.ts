export declare enum EAuthType {
    HRFORTE = "hrforte",
    OCTOPRO = "octopro"
}
