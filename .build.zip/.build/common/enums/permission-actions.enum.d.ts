export declare enum EPermissionActions {
    VIEW = "View",
    EDIT = "Edit",
    EXPORT = "Export",
    DELETE = "Delete",
    CREATE = "Create",
    FULL_ACCESS = "FullAccess",
    NO_ACCESS = "NoAccess"
}
