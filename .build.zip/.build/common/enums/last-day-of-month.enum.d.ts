export declare enum ELastDayOfMonth {
    EACH_MONTH = 32,
    _31_DAYS = 31,
    _30_DAYS = 30,
    LEAP_YEAR = 29,
    NORMAL_YEAR = 28
}
