"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ELeaveDayOff = void 0;
var ELeaveDayOff;
(function (ELeaveDayOff) {
    ELeaveDayOff[ELeaveDayOff["FULL_DAY_OFF"] = 0] = "FULL_DAY_OFF";
    ELeaveDayOff[ELeaveDayOff["HALF_DAY_OFF"] = 0.5] = "HALF_DAY_OFF";
})(ELeaveDayOff || (exports.ELeaveDayOff = ELeaveDayOff = {}));
//# sourceMappingURL=leave-day-off.enum.js.map