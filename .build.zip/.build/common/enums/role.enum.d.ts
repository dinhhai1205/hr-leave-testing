export declare enum ERole {
    ADMIN = "admin",
    ESS = "ess"
}
