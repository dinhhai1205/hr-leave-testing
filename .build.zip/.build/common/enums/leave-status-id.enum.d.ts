export declare enum ELeaveStatusId {
    DRAFT = 0,
    AWAIT_APPROVAL = 1,
    APPROVED = 3,
    DECLINE = 4,
    CANCELLED = 6
}
