export declare enum EWorkDay {
    WORKING_DAY = 1,
    WORKING_HALF_DAY = 0.5,
    DAY_OFF = 0
}
