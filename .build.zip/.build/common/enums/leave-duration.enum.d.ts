export declare enum ELeaveDuration {
    HALF_DAY = 0.5,
    FULL_DAY = 1
}
