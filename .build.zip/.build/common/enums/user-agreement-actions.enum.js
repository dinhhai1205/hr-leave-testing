"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EUserAgreementActions = void 0;
var EUserAgreementActions;
(function (EUserAgreementActions) {
    EUserAgreementActions["AGREE"] = "AGREE";
    EUserAgreementActions["DECLINE"] = "DECLINE";
})(EUserAgreementActions || (exports.EUserAgreementActions = EUserAgreementActions = {}));
//# sourceMappingURL=user-agreement-actions.enum.js.map