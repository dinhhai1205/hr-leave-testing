export declare const TIMESTAMP_STRING = "YYYY-MM-DD HH:mm:ss";
export declare const TIMESTAMP_Z_STRING = "YYYY-MM-DD HH:mm:ssZ";
export declare const DATE_STRING = "YYYY-MM-DD";
export declare const DATE_TIME_STRING = "YYYY-MM-DD HH:mm:ss";
export declare const DAY_OF_WEEK = "ddd";
