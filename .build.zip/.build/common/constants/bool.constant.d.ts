export declare const BOOL: {
    readonly TRUE: "true";
    readonly FALSE: "false";
};
