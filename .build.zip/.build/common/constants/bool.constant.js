"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BOOL = void 0;
exports.BOOL = {
    TRUE: 'true',
    FALSE: 'false',
};
//# sourceMappingURL=bool.constant.js.map