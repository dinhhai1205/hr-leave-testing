"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DAY_OF_WEEK = exports.DATE_TIME_STRING = exports.DATE_STRING = exports.TIMESTAMP_Z_STRING = exports.TIMESTAMP_STRING = void 0;
exports.TIMESTAMP_STRING = 'YYYY-MM-DD HH:mm:ss';
exports.TIMESTAMP_Z_STRING = 'YYYY-MM-DD HH:mm:ssZ';
exports.DATE_STRING = 'YYYY-MM-DD';
exports.DATE_TIME_STRING = 'YYYY-MM-DD HH:mm:ss';
exports.DAY_OF_WEEK = 'ddd';
//# sourceMappingURL=moment-format.constant.js.map