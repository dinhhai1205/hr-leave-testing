export declare const API_BEARER_AUTH_KEY = "API_BEARER_AUTH_KEY";
