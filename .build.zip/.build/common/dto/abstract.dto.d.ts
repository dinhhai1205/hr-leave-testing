export declare class AbstractDto {
    createdOn: Date;
    updatedOn: Date | null;
    deletedOn: Date | null;
    isDeleted: boolean;
}
