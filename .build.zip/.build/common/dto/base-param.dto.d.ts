export declare class BaseParamDto {
    companyId: number;
}
