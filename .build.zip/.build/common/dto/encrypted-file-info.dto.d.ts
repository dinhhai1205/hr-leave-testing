export declare class EncryptedFileInfoDto {
    encryptedSymmetricKey?: string;
    encryptedIv?: string;
    mobileMode: 'yes' | 'no';
}
