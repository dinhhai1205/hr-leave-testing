interface IIsBigintInterface {
    nullable: boolean;
}
export declare const IsHrforteId: (opts?: IIsBigintInterface) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
export {};
