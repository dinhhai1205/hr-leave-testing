interface IIsBigintInterface {
    nullable: boolean;
}
export declare const IsHrforteId: (opts?: IIsBigintInterface) => <TFunction extends Function, Y>(target: object | TFunction, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
export {};
