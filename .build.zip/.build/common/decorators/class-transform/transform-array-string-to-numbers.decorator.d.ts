export declare function TransformArrayStringToNumbers(): PropertyDecorator;
