export declare function TransformStringToBoolean(): PropertyDecorator;
