export declare function TransformRemoveEmptyStringElement(): PropertyDecorator;
