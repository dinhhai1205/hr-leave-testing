export declare function TransformStringToNumber(opts?: Partial<{
    defaultVal: number;
}>): PropertyDecorator;
