import type { Type } from '@nestjs/common';
export declare const ApiOkResponsePaginated: <DataDto extends Type<unknown>>(dataDto: DataDto) => <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
