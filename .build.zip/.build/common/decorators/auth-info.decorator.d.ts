export declare const AuthInfo: (...dataOrPipes: unknown[]) => ParameterDecorator;
