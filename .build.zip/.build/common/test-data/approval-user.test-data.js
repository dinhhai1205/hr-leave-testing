"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.approvalUserTestData = void 0;
exports.approvalUserTestData = {
    isDeleted: false,
    id: 234,
    companyId: 477,
    moduleId: 2,
    orgEleId: 0,
    userEmail1: 'trunglm@zigvy.com',
    userEmail2: '',
    userEmail3: '',
    allMustApprove: false,
    createdBy: 'trunglm@zigvy.com',
    updatedBy: null,
    createdOn: new Date('2023-10-23T00:00:00.000Z'),
    updatedOn: null,
};
//# sourceMappingURL=approval-user.test-data.js.map