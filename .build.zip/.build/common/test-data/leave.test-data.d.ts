import { LeaveEntity } from '../../core/database/entities/leave.entity';
export declare const leaveTestData: LeaveEntity[];
