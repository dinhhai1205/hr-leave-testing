export declare const publicHolidayTestData: {
    id: number;
    date: Date;
}[];
