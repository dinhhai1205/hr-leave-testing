"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.companyTestData = void 0;
const common_test_data_1 = require("../test-data/common.test-data");
exports.companyTestData = {
    id: 477,
    active: true,
    code: 'com.hrforte.alime-boi',
    name: 'Trung Le Ltd',
    ...common_test_data_1.commonTestData,
};
//# sourceMappingURL=company.test-data.js.map