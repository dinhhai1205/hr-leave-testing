"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.commonTestData = void 0;
exports.commonTestData = {
    isDeleted: false,
    createdOn: new Date('2023-11-13T00:00:00.000Z'),
    createdBy: 'trunglm@zigvy.com',
    updatedOn: new Date('2023-11-13T00:00:00.000Z'),
    updatedBy: 'trunglm@zigvy.com',
};
//# sourceMappingURL=common.test-data.js.map