export declare const companyTestData: any;
