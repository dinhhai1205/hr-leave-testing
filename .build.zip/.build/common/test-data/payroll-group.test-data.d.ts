import { EWorkDay } from '../enums';
export declare const payrollGroupTestData: {
    id: number;
    mon: EWorkDay;
    tue: EWorkDay;
    wed: EWorkDay;
    thu: EWorkDay;
    fri: EWorkDay;
    sat: EWorkDay;
    sun: EWorkDay;
    payrollGroupWorkDays: never[];
};
