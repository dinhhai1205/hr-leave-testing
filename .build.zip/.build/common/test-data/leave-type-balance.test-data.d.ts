import { LeaveTypeBalanceEntity } from '../../core/database/entities/leave-type-balance.entity';
export declare const leaveTypeBalanceTestData: LeaveTypeBalanceEntity[];
