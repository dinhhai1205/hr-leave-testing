import { IAuthInfo } from '../interfaces';
export declare const authInfoTestData: IAuthInfo;
