import { LeaveTypePolicyCreditEntity } from '../../core/database/entities/leave-type-policy-credit.entity';
export declare const leaveTypePolicyCreditTestData: LeaveTypePolicyCreditEntity[];
