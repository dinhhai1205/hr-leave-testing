"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.publicHolidayTestData = void 0;
exports.publicHolidayTestData = [
    { id: 2214, date: new Date('2023-01-01T00:00:00.000Z') },
    { id: 2215, date: new Date('2023-01-02T00:00:00.000Z') },
    { id: 2216, date: new Date('2023-01-21T00:00:00.000Z') },
    { id: 2217, date: new Date('2023-01-22T00:00:00.000Z') },
    { id: 2218, date: new Date('2023-01-23T00:00:00.000Z') },
    { id: 2219, date: new Date('2023-01-24T00:00:00.000Z') },
    { id: 2220, date: new Date('2023-01-25T00:00:00.000Z') },
    { id: 2221, date: new Date('2023-01-26T00:00:00.000Z') },
    { id: 2222, date: new Date('2023-04-29T00:00:00.000Z') },
    { id: 2223, date: new Date('2023-04-30T00:00:00.000Z') },
    { id: 2224, date: new Date('2023-05-01T00:00:00.000Z') },
    { id: 2225, date: new Date('2023-05-01T00:00:00.000Z') },
    { id: 2226, date: new Date('2023-05-02T00:00:00.000Z') },
    { id: 2227, date: new Date('2023-09-02T00:00:00.000Z') },
    { id: 2228, date: new Date('2023-09-04T00:00:00.000Z') },
    { id: 2229, date: new Date('2023-11-09T00:00:00.000Z') },
];
//# sourceMappingURL=public-holiday.test-data.js.map