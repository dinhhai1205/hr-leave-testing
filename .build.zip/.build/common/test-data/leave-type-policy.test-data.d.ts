import { LeaveTypePolicyEntity } from '../../core/database/entities/leave-type-policy.entity';
export declare const leaveTypePolicyTestData: LeaveTypePolicyEntity[];
