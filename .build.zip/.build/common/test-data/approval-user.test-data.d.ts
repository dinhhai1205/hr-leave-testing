export declare const approvalUserTestData: {
    isDeleted: boolean;
    id: number;
    companyId: number;
    moduleId: number;
    orgEleId: number;
    userEmail1: string;
    userEmail2: string;
    userEmail3: string;
    allMustApprove: boolean;
    createdBy: string;
    updatedBy: null;
    createdOn: Date;
    updatedOn: null;
};
