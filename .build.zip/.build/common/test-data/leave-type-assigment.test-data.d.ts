import { LeaveTypeAssignmentEntity } from '../../core/database/entities/leave-type-assigment.entity';
export declare const leaveAssignmentTestData: LeaveTypeAssignmentEntity[];
