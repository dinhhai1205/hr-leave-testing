import { LeaveTypeEntity } from '../../core/database/entities/leave-type.entity';
export declare const leaveTypeTestData: LeaveTypeEntity[];
