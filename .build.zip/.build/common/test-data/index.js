"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(require("./approval-user.test-data"), exports);
__exportStar(require("./auth-info.test-data"), exports);
__exportStar(require("./common.test-data"), exports);
__exportStar(require("./company.test-data"), exports);
__exportStar(require("./employee.test-data"), exports);
__exportStar(require("./leave-trx.test-data"), exports);
__exportStar(require("./leave-type-assigment.test-data"), exports);
__exportStar(require("./leave-type-balance.test-data"), exports);
__exportStar(require("./leave-type-policy-credit.test-data"), exports);
__exportStar(require("./leave-type-policy.test-data"), exports);
__exportStar(require("./leave-type.test-data"), exports);
__exportStar(require("./leave.test-data"), exports);
__exportStar(require("./payroll-group-wd.test-data"), exports);
__exportStar(require("./payroll-group.test-data"), exports);
__exportStar(require("./public-holiday.test-data"), exports);
//# sourceMappingURL=index.js.map