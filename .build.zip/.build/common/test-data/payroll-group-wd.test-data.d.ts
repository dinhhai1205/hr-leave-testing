import { EWorkDay } from '../enums';
export declare const payrollGroupWdTestData: {
    value_366: EWorkDay;
    id: number;
    year: number;
    value_1: EWorkDay;
};
