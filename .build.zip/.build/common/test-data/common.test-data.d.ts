import { AbstractEntity } from '../../core/database/entities/abstract.entity';
export declare const commonTestData: AbstractEntity & {
    createdBy: string;
    updatedBy: string;
};
