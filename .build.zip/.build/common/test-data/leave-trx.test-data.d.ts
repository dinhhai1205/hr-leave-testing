import { LeaveTrxEntity } from '../../core/database/entities/leave-trx.entity';
export declare const leaveTrxTestData: LeaveTrxEntity[];
