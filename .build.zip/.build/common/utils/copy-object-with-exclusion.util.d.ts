export declare function copyObjectWithExclusion<T>(originalObject: T, excludedFields: (keyof T)[]): T;
