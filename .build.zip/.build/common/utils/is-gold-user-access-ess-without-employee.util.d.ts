import type { IAuthInfo } from '../interfaces';
export declare function isGoldUserAccessEssWithoutEmp(authInfo: IAuthInfo): boolean;
