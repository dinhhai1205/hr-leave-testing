export declare function capitalized(text?: string): string;
