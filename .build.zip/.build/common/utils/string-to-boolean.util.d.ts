export declare const stringToBoolean: (value: any) => any;
