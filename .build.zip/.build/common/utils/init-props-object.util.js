"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.initPropsObject = initPropsObject;
function initPropsObject(obj = {}, props = {}) {
    return { ...props, ...obj };
}
//# sourceMappingURL=init-props-object.util.js.map