export declare function uniqueArray<T extends string | number | boolean>(array?: T[]): T[];
