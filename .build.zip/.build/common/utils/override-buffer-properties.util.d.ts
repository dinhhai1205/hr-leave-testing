import type { IObjectLiteral } from '../interfaces';
export declare function overrideBufferProperties(obj: IObjectLiteral, newValue: unknown): IObjectLiteral;
