"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.capitalized = capitalized;
function capitalized(text) {
    if (!text)
        return '';
    return text.charAt(0).toUpperCase() + text.slice(1);
}
//# sourceMappingURL=capitalized.util.js.map