export declare function camelToSnakeCase(str?: string): string;
