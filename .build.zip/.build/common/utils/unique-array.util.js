"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.uniqueArray = uniqueArray;
function uniqueArray(array = []) {
    return [...new Set(array)];
}
//# sourceMappingURL=unique-array.util.js.map