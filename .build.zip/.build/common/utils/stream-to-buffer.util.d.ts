export declare function streamToBuffer(readableStream: NodeJS.ReadableStream): Promise<Buffer>;
