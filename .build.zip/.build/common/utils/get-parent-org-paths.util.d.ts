export declare function getParentPaths(orgPaths: string[]): string[];
