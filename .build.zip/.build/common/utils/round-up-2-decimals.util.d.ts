export declare function roundUp2Decimals(n?: number): number;
