export declare function sanitizeFilename(filename: string): string;
