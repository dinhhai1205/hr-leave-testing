export declare function cutFinalSlash(path: string): string;
