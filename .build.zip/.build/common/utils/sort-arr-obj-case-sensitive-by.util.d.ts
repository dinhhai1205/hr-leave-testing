export declare function sortArrObjCaseSensitiveBy<T>(arr?: T[], fieldName?: keyof T): T[];
