export declare const isEmptyObject: <T extends object>(obj: T) => boolean;
