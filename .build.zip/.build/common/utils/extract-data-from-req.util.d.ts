export declare function extractDataFromReq(req: any): {
    method: any;
    url: any;
    body: string;
    ipAddress: any;
    userAgent: any;
    companyId: any;
    userEmail: any;
    authInfo: string;
    currentContext: any;
};
