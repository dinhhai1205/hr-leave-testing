export declare function isFirstIndex(index: number): index is 0;
