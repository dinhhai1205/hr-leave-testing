export declare function chunkArray<T>(array: T[], chunkSize?: number): T[][];
