import type { Request } from 'express';
export declare function extractTokenFromHeader(request: Request): string | undefined;
