export declare function convertObjectKeyToSnakeCase(obj: any, excludeKeys?: string[]): any;
