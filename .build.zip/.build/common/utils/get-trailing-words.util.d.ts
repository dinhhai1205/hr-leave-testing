export declare function getTrailingWords(str: string): string;
