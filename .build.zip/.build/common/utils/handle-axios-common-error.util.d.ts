export declare function handleAxiosCommonError(error: any, errorFormat: {
    messageKey: string;
    statusKey: string;
}): void;
