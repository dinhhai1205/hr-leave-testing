export declare function hasUndefinedOrNullObj<T extends object>(obj: T): boolean;
export declare function hasUndefinedOrNullObjV2<T extends object>(obj: T): string | undefined;
