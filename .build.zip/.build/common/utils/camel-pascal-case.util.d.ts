export declare function camelToPascalCase(str: string, opts?: {
    withSpaces?: boolean;
}): string;
