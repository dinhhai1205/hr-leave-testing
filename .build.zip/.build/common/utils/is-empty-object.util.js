"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isEmptyObject = void 0;
const isEmptyObject = (obj) => {
    return Object.keys(obj).length === 0;
};
exports.isEmptyObject = isEmptyObject;
//# sourceMappingURL=is-empty-object.util.js.map