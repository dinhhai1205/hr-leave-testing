export declare function addEdSuffix(verb: string): string;
