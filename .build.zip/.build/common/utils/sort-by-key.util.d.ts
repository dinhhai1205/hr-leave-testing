import { EOrder } from '../enums';
export declare function sortByKey<T>(array: T[], key: keyof T, order?: EOrder): T[];
