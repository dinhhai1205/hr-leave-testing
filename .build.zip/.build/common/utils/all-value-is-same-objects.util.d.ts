import type { IObjectLiteral } from '../interfaces/object-literal.interface';
export declare function allValueIsSameObjects(source: IObjectLiteral, target: IObjectLiteral): boolean;
