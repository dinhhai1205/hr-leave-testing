export declare function snakeToCamelCase(str?: string): string;
