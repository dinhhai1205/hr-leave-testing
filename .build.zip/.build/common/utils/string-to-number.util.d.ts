export declare const stringToNumber: (val: any, opts?: Partial<{
    defaultVal: number;
}>) => number;
