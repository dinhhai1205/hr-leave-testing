export declare function getYearsInRange(yearFrom: string | number, yearTo: string | number): number[];
