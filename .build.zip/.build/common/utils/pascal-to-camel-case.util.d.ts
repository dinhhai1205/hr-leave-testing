export declare function pascalToCamelCase(obj: any): any;
