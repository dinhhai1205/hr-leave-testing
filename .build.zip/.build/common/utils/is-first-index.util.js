"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isFirstIndex = isFirstIndex;
function isFirstIndex(index) {
    return index === 0;
}
//# sourceMappingURL=is-first-index.util.js.map