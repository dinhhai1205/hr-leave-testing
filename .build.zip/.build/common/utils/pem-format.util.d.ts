export declare function pemFormat(text?: string): string;
