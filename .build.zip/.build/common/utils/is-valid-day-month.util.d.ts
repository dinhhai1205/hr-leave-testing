export declare function isValidHrforteDay(day?: number): boolean;
export declare function isValidHrforteMonth(month?: number): boolean;
export declare function isValidHrforteDayMonth(dateInfo: {
    day: number;
    month: number;
}): boolean;
