import { NestMiddleware } from '@nestjs/common';
import { Request, Response } from 'express';
import { AppConfig } from '../../config/app.config';
export declare class RouteLoggingMiddleware implements NestMiddleware {
    private readonly appConfig;
    private logger;
    constructor(appConfig: AppConfig);
    use(req: Request, res: Response, next: (error?: Error) => void): void;
}
