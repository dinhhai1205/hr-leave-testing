import type { EStorageUnits } from '../enums';
export type CompMeasureUnit = keyof typeof EStorageUnits;
