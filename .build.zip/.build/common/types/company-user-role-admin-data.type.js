"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=company-user-role-admin-data.type.js.map