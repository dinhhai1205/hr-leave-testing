export type EmptyObject = Record<string, never>;
