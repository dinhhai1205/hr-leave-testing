"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=permission-detail.type.js.map